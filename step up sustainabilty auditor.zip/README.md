# Step Up — Unit Cost & Program Sustainability Auditor

An interactive financial dashboard for nonprofit program cost analysis. Built with real Step Up financial data (2016–2023), GAAP compliant, and designed for 2 CFR Part 200 federal grant environments.

## Live Demo

> After deploying, replace with your URL:
> **https://your-username.github.io/stepup-sustainability-auditor/**

---

## What It Does

This tool helps finance and program staff answer three critical questions:

1. **What does it actually cost to serve one student, client, or participant?** — Unit cost analysis using a composite indirect cost allocation method (FTE + sq footage + direct costs)
2. **Are our programs financially sustainable?** — Eight-indicator sustainability audit with benchmarks from Nonprofit Finance Fund
3. **What happens if a grant gets cut?** — Interactive scenario toggle that models service delivery impact of any funding reduction from 0–50%

---

## Features

| Tab | What You See |
|---|---|
| Financial overview | 8-year revenue, expense, and balance sheet trends from actual data |
| Unit cost analysis | Cost per student, cost per placement, direct vs. indirect allocation |
| Scenario toggle | Live slider — drag to model any funding cut, see students/hours lost |
| Sustainability flags | 8 audit indicators with OK / Review / High Risk status |

---

## Data Integrated

All charts and calculations use Step Up's actual financial statements:

- **Income Statement** (2016–2023): Revenue, expenses by category, net change
- **Balance Sheet** (2016–2023): Assets, liabilities, cash, net assets
- **Derived metrics**: Program expense ratio, grant dependency, months of cash reserve, unit costs

---

## Tech Stack

- Pure HTML + CSS + JavaScript — zero build tools, zero dependencies to install
- [Chart.js 4.4.1](https://www.chartjs.org/) via CDN for all visualizations
- Single `index.html` file — open locally or deploy anywhere

---

## Run Locally

```bash
git clone https://github.com/your-username/stepup-sustainability-auditor.git
cd stepup-sustainability-auditor

# macOS
open index.html

# Windows
start index.html

# Linux
xdg-open index.html
```

---

## Deploy to GitHub Pages

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for the full step-by-step guide.

**Quick version:**
1. Push this repo to GitHub
2. Go to Settings → Pages → set branch to `main` → Save
3. Your app is live at `https://your-username.github.io/stepup-sustainability-auditor/`

---

## Project Files

```
stepup-sustainability-auditor/
├── index.html        ← The full app (open this in any browser)
├── README.md         ← This file
├── DEPLOYMENT.md     ← Step-by-step GitHub Pages deploy guide
└── .gitignore        ← Files excluded from Git
```

---

## Compliance Notes

- Follows **GAAP** accounting standards
- Indirect cost allocation aligned with **2 CFR Part 200** Uniform Administrative Requirements
- Sustainability benchmarks sourced from Nonprofit Finance Fund and GuideStar sector data

---

## Key Findings from the Data

- 2023 operating **deficit of ($305,774)** — second deficit in four years
- **Grant dependency at 84.6%** — significantly above the 70% sector caution threshold
- **Program expense ratio of 83.2%** — below the 85% nonprofit benchmark
- **M&G costs rose 30% YoY** (2022: $184K → 2023: $240K)
- Despite the deficit, **cash reserves cover ~9.5 months** of operating expenses
