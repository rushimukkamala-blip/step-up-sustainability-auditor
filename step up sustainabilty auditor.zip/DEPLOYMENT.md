# Deployment Guide — GitHub Pages

Step-by-step instructions to publish the Step Up Unit Cost Auditor as a live website using **GitHub Pages** — free, no server needed.

---

## What You Need

- A free [GitHub account](https://github.com/signup)
- [Git](https://git-scm.com/downloads) installed on your computer
- The 4 project files in one folder on your computer:
  ```
  stepup-sustainability-auditor/
  ├── index.html
  ├── README.md
  ├── DEPLOYMENT.md
  └── .gitignore
  ```

---

## Step 1 — Create a GitHub Repository

1. Sign in to [github.com](https://github.com)
2. Click the **"+"** icon (top right) → **"New repository"**
3. Fill in the details:
   - **Repository name:** `stepup-sustainability-auditor`
   - **Description:** `Interactive unit cost and program sustainability dashboard for Step Up`
   - **Visibility:** Select **Public** *(required for free GitHub Pages)*
   - Leave **"Initialize this repository"** unchecked
4. Click **"Create repository"**
5. On the next screen, **copy the repository URL** — it looks like:
   ```
   https://github.com/your-username/stepup-sustainability-auditor.git
   ```

---

## Step 2 — Open a Terminal on Your Computer

**Windows:**
- Open the folder where your files are saved in File Explorer
- Click the address bar at the top → type `cmd` → press Enter
- A black terminal window opens already inside your folder

**Mac:**
- Press `Cmd + Space` → type `Terminal` → press Enter
- Then navigate to your folder:
  ```bash
  cd Desktop/stepup-sustainability-auditor
  ```
  *(replace Desktop with wherever you saved the folder)*

**Don't have Git?**
- Download and install it from [git-scm.com/downloads](https://git-scm.com/downloads)
- Restart the terminal and continue

---

## Step 3 — Push Files to GitHub

Copy and paste each command one at a time, pressing Enter after each:

```bash
# Navigate into your project folder (skip if terminal already there)
cd path/to/stepup-sustainability-auditor

# Initialize Git in the folder
git init

# Stage all files for commit
git add .

# Save your first commit
git commit -m "Initial commit — Step Up sustainability auditor"

# Rename the branch to 'main'
git branch -M main

# Connect to your GitHub repo (paste YOUR URL from Step 1)
git remote add origin https://github.com/your-username/stepup-sustainability-auditor.git

# Upload your files to GitHub
git push -u origin main
```

After the last command, go to your GitHub repository page and refresh — all 4 files should appear.

---

## Step 4 — Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **"Settings"** tab (in the top navigation bar of your repo)
3. In the left sidebar, scroll down and click **"Pages"**
4. Under **"Branch"**, click the dropdown that says `None`
5. Select **`main`**
6. Make sure the folder dropdown shows **`/ (root)`**
7. Click **"Save"**

You'll see a message: *"Your site is being deployed..."*

---

## Step 5 — Get Your Live URL

Wait **1–3 minutes**, then refresh the Pages settings page.

You'll see a green box:
> **Your site is live at:**
> `https://your-username.github.io/stepup-sustainability-auditor/`

Click the link — your dashboard is now live and shareable with anyone.

---

## Step 6 — Share It

Copy the URL and share with:
- Your finance team
- Program directors
- Board members
- Funders (for grant reporting transparency)

No login required to view — anyone with the link can access it.

---

## Updating the App Later

Any time you make changes to `index.html`, run these three commands to push the update. GitHub Pages will redeploy automatically within 1–2 minutes:

```bash
git add index.html
git commit -m "describe your change here"
git push
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| **404 error on the live URL** | Make sure the file is named exactly `index.html` (all lowercase) |
| **Changes not showing up** | Wait 2–3 minutes then hard-refresh: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac) |
| **"Permission denied" error on push** | Run `git config --global user.email "you@email.com"` then retry |
| **"Repository not found" error** | Double-check the URL in your `git remote add` command |
| **Charts not loading** | Make sure you have an internet connection — Chart.js loads from a CDN |
| **Private repo, Pages not working** | Free GitHub Pages requires a Public repo. Change visibility in Settings → General |

---

## Optional: Custom Domain

If you want the app at a custom URL like `finance.stepup.org`:

1. In **Settings → Pages**, enter your domain under **"Custom domain"**
2. Add a file named `CNAME` to your repo containing just your domain:
   ```
   finance.stepup.org
   ```
3. Update your domain's DNS with your registrar:
   - Add 4 A records pointing to GitHub's IPs: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - Or add a CNAME record pointing to `your-username.github.io`
4. Wait up to 48 hours for DNS to propagate

Full guide: [docs.github.com/pages/custom-domain](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site)
